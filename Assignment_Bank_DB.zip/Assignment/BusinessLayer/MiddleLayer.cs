﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DBConnection;
namespace BusinessLayer
{
    public class MiddleLayer
    {
        DBConnection1 db = new DBConnection1();
        Client client = new Client();
        public void BL_GetDetails()
        {

            List<Client> clientInfo = new List<Client>();


            clientInfo = db.GetDetails();

            if (clientInfo.Count == 0)
                Console.WriteLine("No client exists!\n");
            else
            {
                for (int i = 0; i < clientInfo.Count; i++)
                {
                    Console.WriteLine(" --Account holder--  {0} ", clientInfo[i].AccountHolder);
                    Console.WriteLine(" --Account number--  {0} ", clientInfo[i].AccountNumber);
                    Console.WriteLine(" --Account type--    {0} ", clientInfo[i].AccountType);
                    Console.WriteLine(" --Amount--          {0} ", clientInfo[i].Amount);
                }
            }
        }

        public void BL_CreateCustomer(Client newClientObj)
        {
            bool result = db.AddAccount(newClientObj);
            if (result == true)
                Console.WriteLine(" Account added successfully! ");
            else
                Console.WriteLine(" Error occured! Please contact admin. ");
        }

        public void BL_SearchByID(int clientId)
        {
            Client SearchResult = db.SearchById(clientId);
            if (SearchResult != null)
            {
                Console.WriteLine(" {0} ", SearchResult.AccountNumber);
                Console.WriteLine(" {0} ", SearchResult.AccountHolder);
                Console.WriteLine(" {0} ", SearchResult.AccountType);
                Console.WriteLine(" {0} ", SearchResult.Amount);
            }
            else
                Console.WriteLine("No user exists with {0} Account number ", clientId);
        }

        public void BL_Deposit(int clientId, int extraAmount)
        {
            bool depositResult = db.Deposit(clientId, extraAmount);
            if (depositResult == true)
                Console.WriteLine(" Amount updated successfully! ");
            else
                Console.WriteLine(" Error occured! Please contact admin. ");
        }

        public void BL_Withdraw(int clientId, int removedAmount)
        {
            bool depositResult = db.Withdraw(clientId, removedAmount);
            if (depositResult == true)
                Console.WriteLine(" Amount updated successfully! ");
            else
                Console.WriteLine(" Error occured! Please contact admin. ");
        }

        public void BL_Interest(int clientId)
        {
            double interestAmount = db.CalculateInterest(clientId);
            Console.WriteLine("--Calculated interest-- {0}", interestAmount);
        }
    }

}