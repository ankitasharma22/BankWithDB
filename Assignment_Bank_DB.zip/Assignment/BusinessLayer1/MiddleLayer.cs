﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer1;
using DBConnection;

namespace BusinessLayer1
{
    public class MiddleLayer
    {
        public void BL_GetDetails()
        {
            DBConnection1 db = new DBConnection1();
            List<Client> clientInfo = new List<Client>();
            Client client = new Client();

            clientInfo = db.GetDetails();

            if (clientInfo.Count == 0)
                Console.WriteLine("No client exists!\n");
            else
            {
                for (int i = 0; i < clientInfo.Count; i++)
                {
                    Console.WriteLine(" {0} ", clientInfo[i]);
                }
            }
        }
    }
}
