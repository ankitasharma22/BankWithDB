﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace DBConnection
{
    public class DBConnection1
    {
        public List<Client> GetDetails()
        {
            Class1 c1 = new Class1();
            List<Client> clientDetails = new List<Client>();
            c1.Connection();
            SqlCommand cmd = c1.connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Bank_GetAllDetails1";
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                Client client = new Client();
                client.AccountNumber = Convert.ToInt32(rdr["AccountNumber "]);
                client.AccountHolder = rdr["AccountHolder"].ToString();

                client.AccountType = rdr["AccountType"].ToString();

                client.Amount = Convert.ToInt32(rdr["Amount"]);

                clientDetails.Add(client);
            }
            c1.connection.Close();
            return clientDetails;
        }

        public bool AddAccount(Client newClient)
        {
            Class1 c1 = new Class1();
            c1.Connection();

            SqlCommand cmd = c1.connection.CreateCommand();

            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Name", newClient.AccountHolder); //Account Holder name
            cmd.Parameters.AddWithValue("@Type", newClient.AccountType); //Account type
            cmd.Parameters.AddWithValue("@Amount", newClient.Amount); //Amount
            cmd.CommandText = "Bank_CreateCustomer";
            int rowsAffected = cmd.ExecuteNonQuery();
            c1.connection.Close();
            if (rowsAffected > 1)
                return true;
            else return false;

        }

        public Client SearchById(int clientID)
        {
            Class1 c1 = new Class1();
            Client client = new Client();
            c1.Connection();
            SqlCommand cmd = c1.connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Account", clientID); //Account Number
            cmd.CommandText = "Bank_SearchById";
            SqlDataReader rdr = cmd.ExecuteReader();
            try
            {
                while (rdr.Read())
                {
                    client.AccountHolder = rdr["AccountHolder"].ToString();
                    client.AccountNumber = clientID;
                    client.AccountType = rdr["AccountType"].ToString();
                    client.Amount = Convert.ToInt32(rdr["Amount"]);
                }
            }
            catch (Exception exe)
            {
                Console.WriteLine(" No user exists! ");
            }
            c1.connection.Close();
            return client;
        }

        public bool Deposit(int clientID, int amountToBeAdded)
        {
            Class1 c1 = new Class1();
            c1.Connection();
            SqlCommand cmd = c1.connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Account", clientID); //Account Number
            cmd.Parameters.AddWithValue("@AmountToBeAdded", amountToBeAdded); //Amount increase
            cmd.CommandText = "Bank_Deposit"; //proc name
            int updationResult = cmd.ExecuteNonQuery();

            c1.connection.Close();
            if (updationResult > 1)
                return true;
            else return false;
        }

        public bool Withdraw(int clientID, int amountToBeWithdrawn)
        {
            Class1 c1 = new Class1();
            c1.Connection();
            SqlCommand cmd = c1.connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Account", clientID); //Account Number
            cmd.Parameters.AddWithValue("@AmountToBeWithdrawn", amountToBeWithdrawn); //Amount increase

            Client c2 = new Client();
            c2 = SearchById(clientID);

            if (c2.AccountType == "Saving" && c2.Amount - amountToBeWithdrawn >= 1000)
                cmd.CommandText = "Bank_Withdraw";
            else if (c2.AccountType == "Current" && c2.Amount - amountToBeWithdrawn >= 0)
                cmd.CommandText = "Bank_Withdraw";
            else if (c2.AccountType == "DMAT" && c2.Amount - amountToBeWithdrawn >= -10000)
                cmd.CommandText = "Bank_Withdraw";
            else
                Console.WriteLine("Minimum Balance is to be maintained!!! Insufficient balance. ");

            int updationResult = cmd.ExecuteNonQuery();
            c1.connection.Close();
            if (updationResult > 1)
                return true;
            else return false;
        }
        public double CalculateInterest(int clientID)
        {
            Client clientObj = new Client();
            clientObj = SearchById(clientID);
            string accountType = clientObj.AccountType;
            double amount = clientObj.Amount;
            if (accountType == "Saving")
                return amount * 0.04;
            else if (accountType == "Current")
                return amount * 0.01;
            else
                return 0;
        }

        
    }
}
