﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBConnection
{
    public class Class1
    {
       public  SqlConnection connection;
        public void Connection()
        {
            SqlCommand command;
            string sql = null;
            connection = new SqlConnection();
            try
            {
                connection.ConnectionString = "Data Source=TAVDESK033;Initial Catalog=BankAccount ;User ID=sa ;Password=test123!@#";
                connection.Open();
                command = new SqlCommand(sql, connection);
                command.Dispose();

                //Console.WriteLine(" ExecuteNonQuery in SqlCommand executed !!");
                //Console.WriteLine("-- " + command);
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Cant open!");
            }
          
        }
    }
}
