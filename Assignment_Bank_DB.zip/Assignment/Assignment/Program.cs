﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DBConnection;
namespace Assignment
{
    class Program
    {
        static void Main(string[] args)
        {

            Class1 DbObject = new Class1();
            DbObject.Connection();
            Console.ReadKey();
        }
    }
}
