﻿using System;
using BusinessLayer;
using DBConnection;

namespace ConsoleApp
{
    class UserInteraction
    {

        public static void Main(string[] args)
        {
            Console.WriteLine("******* WELCOME TO TAVISCA SOLUTIONS BANK ********");
            Console.WriteLine();

            Class1 c1 = new Class1();
            bool flag = false;
            int userChoice = 0;
            MiddleLayer middleLayer = new MiddleLayer();
            

            do {
                Console.WriteLine(" --- CHOOSE YOUR ACTION AMONG THE FOLLOWING ---");
                Console.WriteLine("1. Create Bank Account ");
                Console.WriteLine("2. Search Account By Account Number ");
                Console.WriteLine("3. See all customer details ");
                Console.WriteLine("4. Deposit Money ");
                Console.WriteLine("5. Withdraw Money");
                Console.WriteLine("6. Calculate Interest ");
                Console.WriteLine("7. Exit ");
                userChoice = Convert.ToInt32(Console.ReadLine());
                switch (userChoice)
                {
                    case 1:
                        Client newClient = new Client();
                        Console.WriteLine("_______HELLO NEW USER!________");
                        Console.WriteLine("Enter Account Holder name ");
                        newClient.AccountHolder = Console.ReadLine();
                        Console.WriteLine("Enter Amount ");
                        newClient.Amount = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Account Type ");
                        Console.WriteLine("*****Valid Account Types*****");
                        Console.WriteLine("Saving / Current / DMAT ");
                        do
                        {
                            newClient.AccountType = Console.ReadLine();
                            if (!(newClient.AccountType == "Saving" || newClient.AccountType == "Current" || newClient.AccountType == "DMAT"))
                            {
                                Console.WriteLine("Wrong entry. Please try again. ");
                                flag = true;
                            }
                            else
                                flag = false;
                        } while (flag);
                        middleLayer.BL_CreateCustomer(newClient);

                        break;
                    case 2:
                        Client newClient1 = new Client();
                        Console.WriteLine("_______SEARCH BY ACCOUNT NUMBER________");
                        Console.WriteLine("Enter Account Number ");
                        newClient1.AccountNumber = Convert.ToInt32(Console.ReadLine());
                        middleLayer.BL_SearchByID(newClient1.AccountNumber);
                        break;
                    case 3:
                        Console.WriteLine("_______GET DETAILS OF ALL EXISTING CLIENTS________");
                        middleLayer.BL_GetDetails();
                        break;
                    case 4:
                        Console.WriteLine("_______DEPOSIT MONEY________");
                        Console.WriteLine("Enter Account Number ");
                        int account1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Deposit Money");
                        int depositMoney = Convert.ToInt32(Console.ReadLine());
                        middleLayer.BL_Deposit(account1, depositMoney);
                        break;
                    case 5:
                        Console.WriteLine("_______WITHDRAW MONEY________");
                        Console.WriteLine("Enter Account Number ");
                        int account2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Withdraw Money");
                        int withdrawMoney = Convert.ToInt32(Console.ReadLine());
                        middleLayer.BL_Deposit(account2, withdrawMoney);
                        break;
                    case 6:
                        Console.WriteLine("____CALCULATE INTEREST____");
                        Console.WriteLine("Enter Account Number ");
                        int accountNo = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Interest is calculated as per account type...");
                        Console.WriteLine("Saving Account - 40%, Current Account - 10%");
                        middleLayer.BL_Interest(accountNo);
                        break;
                    default:
                        Console.WriteLine(" You entered a wrong choice! Please try again. ");
                        break;

                }
            } while (userChoice != 7);

            c1.Connection();
            
            Console.ReadKey();
        }
    }
}
